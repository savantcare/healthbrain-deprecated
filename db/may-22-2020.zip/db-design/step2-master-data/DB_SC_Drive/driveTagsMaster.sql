use DB_SC_Drive
-- MySQL dump 10.13  Distrib 5.7.28, for Linux (x86_64)
--
-- Host: localhost    Database: DB_SC_Drive
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `driveTagsMaster`
--

DROP TABLE IF EXISTS `driveTagsMaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driveTagsMaster` (
  `tagID` int(11) NOT NULL AUTO_INCREMENT,
  `tagName` varchar(255) NOT NULL,
  `createdOn` datetime DEFAULT NULL,
  `createdOnTimezone` varchar(10) DEFAULT NULL,
  `uidOfCreatedBy` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`tagID`),
  KEY `tagMasterUidOfCreatedByIndex` (`uidOfCreatedBy`),
  CONSTRAINT `driveTagsMaster_ibfk_1` FOREIGN KEY (`uidOfCreatedBy`) REFERENCES `DB_SCEMR_PROD`.`users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driveTagsMaster`
--

LOCK TABLES `driveTagsMaster` WRITE;
/*!40000 ALTER TABLE `driveTagsMaster` DISABLE KEYS */;
INSERT INTO `driveTagsMaster` VALUES (1,'Bug - Open','2016-07-07 22:48:35',NULL,976),(2,'Training','2016-07-07 22:40:35',NULL,976),(3,'Bug - resolved',NULL,NULL,NULL),(4,'Feature request - Open',NULL,NULL,NULL),(5,'Feature request - closed',NULL,NULL,NULL),(6,'Module testing',NULL,NULL,NULL),(7,'SC1 construction',NULL,NULL,NULL),(8,'Scanned Docs','2016-08-09 00:00:00','PST',440),(9,'Scanned Mail','2016-09-01 21:10:15','IST',538),(10,'Video Stories','2016-12-09 17:52:29','PST',1050);
/*!40000 ALTER TABLE `driveTagsMaster` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
